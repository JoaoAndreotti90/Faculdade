document.getElementById("cadastroBtn").addEventListener("click", function() {
    window.location.href = "php/login.php";
});

document.getElementById("vendaBtn").addEventListener("click", function() {
    window.location.href = "php/venda.php";
});