
document.getElementById("clientesBtn").addEventListener("click", function() {
    window.location.href = "./clientes/clientes.php";
});

document.getElementById("vendedoresBtn").addEventListener("click", function() {
    window.location.href = "./vendedores/vendedores.php"; 
});

document.getElementById("produtosBtn").addEventListener("click", function() {
    window.location.href = "./produtos/produtos.php"; 
});

document.getElementById("voltarBtn").addEventListener("click", function() {
    window.location.href = "../index.php";
});